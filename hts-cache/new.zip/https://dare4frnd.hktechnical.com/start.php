<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<script src="/cdn-cgi/apps/head/W1LCboOBIap2E3J0q74YikrldxI.js"></script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-127337837-16" type="03eb373920310484ee41a482-text/javascript"></script>
<script type="03eb373920310484ee41a482-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-127337837-16');
</script>
<meta name="description" content="Fill in the Blanks Game on Dare4Frnd Lets See What Your Friends Answers 7 Personel things of you">
<title>7 Fill in the Blanks Game |  |</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/custom.css?v=1.1">
<link rel="canonical" href="https://Dare4Frnd.hktechnical.com/">
<meta property="og:url" content="https://Dare4Frnd.hktechnical.com/">
<meta property="og:type" content="website">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta property="og:title" content="7 Fill in the Blanks Game |  |">
<meta name="twitter:title" content="7 Fill in the Blanks Game |  |">
<meta property="og:description" content="Fill in the Blanks Game on Dare4Frnd Lets See What Your Friends Answers 7 Personel things of you">
<meta name="twitter:description" content="Fill in the Blanks Game on Dare4Frnd Lets See What Your Friends Answers 7 Personel things of you">
<meta property="og:image" content="https://oyedare.com/img/share.jpg">
<meta name="twitter:image" content="https://oyedare.com/img/share.jpg">
<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="theme-color" content="#ffffff">
<script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js" type="0cdeca6bff7a39fc4b7c0a2d-text/javascript"></script>
<script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js" type="03eb373920310484ee41a482-text/javascript"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/progressive-image.js/dist/progressive-image.css">
<script src="https://cdn.jsdelivr.net/npm/progressive-image.js/dist/progressive-image.js" type="03eb373920310484ee41a482-text/javascript"></script>
<script async src='/cdn-cgi/challenge-platform/h/g/scripts/invisible.js'></script></head>
<section class="hero is-fullheight">
<div class="hero-head" style="width:100%;position:fixed;z-index:999999; background-color:white;box-shadow:2px 2px 1px black;">
<header class="navbar has-shadow">
<div class="container">
<div class="navbar-brand" style="position:relative;">
<a href="/" class="navbar-item">
<img src="https://1.bp.blogspot.com/-vQcK9MHM6xw/Xt4O0xXINQI/AAAAAAAADyM/YDubYlzW4IoDt_YpQSDjWnJUJl1oN5ATACK4BGAsYHg/MyLogoArt20200608153727.png" style="width:150px;height:auto;max-height: 100px;" alt="Logo">
</a>
<span onclick="if (!window.__cfRLUnblockHandlers) return false; openMySideNav()" id="sidenavburger" class="navbar-burger burger sidenavburger" style="position:fixed;right:0;" data-target="navbarMenuHeroC" data-cf-modified-03eb373920310484ee41a482-="">
<span></span>
<span></span>
<span></span>
</span>
</div>
<div id="navbarMenuHeroC" class="navbar-menu">
<div class="navbar-end">
<a href="/" class="navbar-item">
<span class="icon">
<i class="fas fa-home"></i>
</span>
&nbsp;Home
</a>
<a href="#/about-us/" class="navbar-item">
<span class="icon">
<i class="fas fa-user"></i>
</span>
&nbsp;About Us
</a>
<a href="#/social/" class="navbar-item">
<span class="icon">
<i class="fas fa-hashtag"></i>
</span>
&nbsp;Social
</a>
<a href="contact.php" class="navbar-item">
<span class="icon">
<i class="fas fa-paper-plane"></i>
</span>
&nbsp;Contact Us
</a>
<span class="navbar-item">
<div class="buttons">
<a href="how-to.php" class="button is-success">
<span class="icon">
<i class="fas fa-question-circle"></i>
</span>
<span>How to Play</span>
</a>
<a href="contact.php" class="button is-danger">
<span class="icon">
<i class="fas fa-bug"></i>
</span>
<span>Report Problem</span>
</a>
</div>
</span>
</div>
</div>
</div>
</header>
</div>
<style>
.mysidenav {
  margin-top:50px;
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 999;
  top: 0;
  right: 0;
  background: url('img/educationtoday.png');
  background-repeat: no-repeat;
  overflow-x: hidden;
  transition: 0.5s;
  
}
.mysidenavbody{
	padding-top: 10px;
	background: rgba(255, 233, 217, 0.7);
	height: 100%;
}
.mysidenav .mysidenav-item {
	margin: 0px 7px 7px 7px;
	padding: 5px;
	background: rgba(190, 250, 175, 0.7);	
}

.mysidenav a {
  text-decoration: none;
  font-size: ;
  color: ;
  display: block;
  transition: 0.5s;
}
.mysidenav .mysidenav-item:hover {
  color: blue;
  background: rgba(208, 255, 89, 0.8);
  
}

.mysidenav .mysidenav-closebtn {
  position: absolute;
  top: 2px;
  right: 10px;
  padding:0px 10px;
  font-size: 36px;
  margin-left: 50px;
  border-radius:5px;
  background: rgba(100, 100, 100, 0.9);
  color:white;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
  
} 
</style>
<script type="03eb373920310484ee41a482-text/javascript">
function openMySideNav() {
	  var element = document.getElementById("sidenavburger");
var sidenavburger = document.getElementsByClassName('sidenavburger');
if (sidenavburger.length > 0) {
 
  element.classList.remove("sidenavburger");
  document.getElementById("myaddSidenav").style.width = "250px";
} else{
  element.classList.add("sidenavburger");
   document.getElementById("myaddSidenav").style.width = "0";
}
}


</script>
<div id="myaddSidenav" class="mysidenav">
<div class="mysidenavbody">
<a class="mysidenav-item" href="/"><span class="icon"><i class="fas fa-home"></i></span>&nbsp;Home</a>
<a class="mysidenav-item" href="#"><span class="icon"><i class="fas fa-user"></i></span>&nbsp;About Us</a>
<a class="mysidenav-item" href="#"><span class="icon"><i class="fas fa-hashtag"></i></span>&nbsp;Social</a>
<a class="mysidenav-item" href="/contact.php"><span class="icon"><i class="fas fa-paper-plane"></i></span>&nbsp;Contact Us</a>
<label style="padding-left:10px;">More:</label>
<a href="how-to.php" class="mysidenav-item button is-success" style="color:green;"><span class="icon"><i class="fas fa-question-circle"></i></span><span>How to Play</span></a>
<a href="contact.php" class="mysidenav-item button is-danger" style="color:red;"><span class="icon"><i class="fas fa-bug"></i></span><span>Report Problem</span></a>
</div>
</div>
<style>
.hero-body{
	padding-top:100px;
}
</style><div class="hero-body">
<div class="container" style="max-width:500px;">
<center>
<div class="columns">
<div class="column is-12">
<h1 class="subtitle">Enter Your Name</h1>
</div>
</div>
<form method="post" action="dare-list.php">
<div class="columns is-centered">
<div class="column is-12">
<div class="field">
<div class="control">
<input class="input is-rounded" name="userName" id="userName" type="text" placeholder="name..." autocomplete="off" required>
</div>
</div>
</div>
</div>
<div class="columns is-centered">
<div class="column is-12 ">
<div class="field">
<div class="control has-text-centered">
<button style="width: 200px;" class="button is-medium is-primary is-rounded">Start</button>
</div>
</div>
</div>
</div>
</form>
</center>
</div>
</div>
<div id="snackbar"></div>
<script type="b76c9840ea4f44c1fe476569-text/javascript">
function validate(){
    var regName = /^[a-zA-Z\s]+$/;
    var name = document.getElementById('userName').value;
	name=name.replace(/ /g, '');
    if(!regName.test(name)){
		console.log(name);
        displayError('Please Enter Your Name Correctly');
		document.getElementById('userName').value='';
        document.getElementById('userName').classList.add('is-danger');
        return false;
    }else{
        return true;
    }
}
function displayError(error) {
  var x = document.getElementById("snackbar");
  x.innerHTML=error;
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}	
</script>
<div class="hero-foot">
<footer class="footer">
<div class="content has-text-centered">
<p> Made with <i class="fas fa-heart has-text-danger"></i> </p>
<p>
<a href="#"><img class="icon" src="img/icons/instagram.svg" /> </a>
<a href="#">&nbsp;<img class="icon" src="img/icons/facebook.svg" /> </a>
<a href="#">&nbsp;<img class="icon" src="img/icons/twitter.svg" /> </a>
</p>
<p> (c) <span class="has-text-link">Dare4Frnd</span> 2020 </p>
</div>
</footer>
</div>
</section>
<script type="b76c9840ea4f44c1fe476569-text/javascript">
document.addEventListener('DOMContentLoaded', () => {

  // Get all "navbar-burger" elements
  const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);

  // Check if there are any navbar burgers
  if ($navbarBurgers.length > 0) {

    // Add a click event on each of them
    $navbarBurgers.forEach( el => {
      el.addEventListener('click', () => {

        // Get the target from the "data-target" attribute
        const target = el.dataset.target;
        const $target = document.getElementById(target);

        // Toggle the "is-active" class on both the "navbar-burger" and the "navbar-menu"
        el.classList.toggle('is-active');
    //    $target.classList.toggle('is-active');

      });
    });
  }

});
</script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/95c75768/cloudflare-static/rocket-loader.min.js" data-cf-settings="b76c9840ea4f44c1fe476569-|49" defer="" type="03eb373920310484ee41a482-text/javascript"></script><script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="03eb373920310484ee41a482-|49" defer=""></script><script type="text/javascript">(function(){window['__CF$cv$params']={r:'6c820148ebe21d20',m:'EJjM4B1n7RqG.CkAEOjt7DEnLLCELGaTf0q8QuIozYA-1641273493-0-ARIksRrLra6B5c2JrkfAYeTzheKn/j/kQkntOmbOjPxPwJbqf6ueuovFReRQL3OiRFIvV3z4putIGIFKb082sfEVIuKcx8P6MQnZz52GolJaiOyrCrFrFLN9NfQX7bx8Ng==',s:[0xad877150c2,0xeeffc284d1],u:'/cdn-cgi/challenge-platform/h/g'}})();</script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6c820148ebe21d20","version":"2021.12.0","r":1,"token":"8b503279a5a4404cbdbe51f8650e88eb","si":100}' crossorigin="anonymous"></script>
</body>
</html>